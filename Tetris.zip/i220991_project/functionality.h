/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */
//Afnan Hassan 22i-0991 Final Project
//---Piece Starts to Fall When Game Starts---//
void fallingPiece(float& timer, float& delay, int& colorNum){
    if (timer>delay){
        for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            point_1[i][1]+=1;                   //How much units downward
        }
        delay=0.3;
        if (!anamoly()){
        for (int i=0;i<4;i++)
        gameGrid[point_2[i][1]][point_2[i][0]]=colorNum;
        colorNum=1+rand()%7;
         int n=rand()%7;
            
                for (int i=0;i<4;i++){
                    point_1[i][0] = BLOCKS[n][i] % 2;
                    point_1[i][1] = BLOCKS[n][i] / 2;
                }
            
        }
        timer=0;
    }
}

/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///
void rightshift(int &delta_x)
{
   if (delta_x==1)            //checking if the right key is pressed
   {
     for(int i=0;i<4;i+=1)
     {
       point_1[i][0]+=1;      //shifting the points to the right
     }
     
     if (!anamoly())          //checking if the block gets out of the frame
     {
        for (int i=0;i<4;i++)
        {
           point_1[i][0]-=1; //shifting the blocks left so they donot get out of the frame
        }
     }
     delta_x=0;              //resetting the delta_x
   }
   
}

void leftshift(int &delta_x)
{
   if (delta_x==-1)          //checking if the left key is pressed
   {
     for(int i=0;i<4;i+=1)
     {
       point_1[i][0]-=1;     //shifting the point s to the left
     }
     
     if (!anamoly())        // checking if the blocks are getting of the grid
     {
        for (int i=0;i<4;i++)
        {
           point_1[i][0]+=1;//shifting the blocks right so they dono get out of the frame
        }
     }
     delta_x=0;
   }
   
}
void R(bool &rotate)
{      
       
       if (rotate==true)     //checking if the up key is pressed
       {  
          for(int i=0;i<4;i++)
          {
             for (int j=0;j<2;j++)
             {
                point_2[i][j]=point_1[i][j];  //saving the point_1 array in point_2 for later
             }
          }
             for (int i=0; i<4;i++)
             {
                int x=point_1[i][1]-point_1[1][1]; //shifting the points for the rotation
                int y=point_1[i][0]-point_1[1][0]; //shifting the points for the rotation
                
                point_1[i][0]=point_1[1][0] -x;
                point_1[i][1]=point_1[1][1] +y;
             } 
             if (!anamoly())                 //checking if the blocks getting out of the frame
             {
                for(int i=0;i<4;i++)
                {
                    for (int j=0;j<2;j++)
                   {
                      point_1[i][j]=point_2[i][j]; //resetting the value of the point_1 back to initial
                   }
                }
             }        
       }
        rotate=false;
     
}


void space( float&delay)
{
   for (int i=0;i<M-1;i++)
   {
      
      
   }
   
}

void removeline(int &scr)
{  
    for(int k=1; k==1;k++)
    {
    int score=0;                     //resetting the score for every iteration
    for(int i=M-1;i>0;i--)
    {
       int c=0;                      //resetting the counter for every iteration
       for (int j=0; j<N;j++)
       {
           if (gameGrid[i][j])       //checking if a block exist at a point in the top most line
           {
              c++;
           }
           
       }
       if (c==N)
       {
          score++;
       }
       
    }
    if (score==1)              //
    scr+=10;                   //
    if(score==2)               //
    scr+=30;           // adding the score according to the lines removed
    if(score==3)               //
    scr+=60;                   //
    if (score==4)              //
    scr+=100;                  //
    
    }  
    
    for (int i=0; i==0; i++)
    {   
    int x=M-1;
    for (int i=M-1;i>0;i--)
    {   
        int count=0, c=0;
        for (int j=0;j<N;++j)
        {
            if (gameGrid[i][j]){
            count++;
            }
            gameGrid[x][j]=gameGrid[i][j];  //storing the grid so that if the line is removed the line move downwards
            
        }
        if (count<N){                       //if the blocks are less than the number of columns then the k decreases and the line does not dissapear
         --x;}
      } 
      
      }   
      
      

}

int gameover()
{
    int i=0, c=0;
     for (int j=0;j<N;j++)   
        {
      if (gameGrid[i][j])   //checking if the top line has block
        {
             return 1;
        }
       else
           return 0;          
        }
        return 0;
}


void shadow_placement()
{
   for (int i=0;i<4;++i)
   {  
      shadowpos[i][0]=point_1[i][0];    //duplication the block to its shadow array
      shadowpos[i][1]=point_1[i][1];
   }
   while(anamoly2())
   {
      for (int i=0;i<4;i++)             //checking if the block gets out of the frame overlaps another block
      {
         shadowpos[i][1]++;
      }
   }
}




///*** YOUR FUNCTIONS END HERE ***///
/////////////////////////////////////
