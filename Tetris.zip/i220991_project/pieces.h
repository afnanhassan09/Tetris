/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 //Afnan Hassan 22i-0991 Final Project
 
 int BLOCKS[7][4]={
            {1,3,5,7},//I.
            {3,5,7,6},//J.
            {2,4,6,7},//L.
            {4,7,5,6},//O.
            {0,2,3,5},//S.
            {1,3,2,4},//Z.
            {1,3,5,2}//T.
            };
